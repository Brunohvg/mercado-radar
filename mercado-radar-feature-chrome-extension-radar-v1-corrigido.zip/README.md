# Mercado Radar

**Copiloto de compra e rentabilidade para quem revende no Mercado Livre.** Decide o que comprar, quanto pagar, quanto cobrar, quanto realmente sobrou e onde vale colocar capital.

## Direção do produto

O Mercado Radar não é um clone do Seller Center. Produtos e Vendas existem para gerar decisão, não para repetir telas do Mercado Livre.

## Os quatro pilares

1. **Sourcing** — o que comprar e quanto pagar;
2. **Pricing** — por quanto vender sem destruir margem;
3. **Profit** — quanto realmente sobrou;
4. **Capital & Estoque** — repor, reduzir ou parar.

O Mercado Radar é um sistema completo, não um conjunto de automações externas.

As integrações, cálculos, sincronizações, regras de preço, histórico, alertas e decisões ficam versionadas dentro do próprio projeto. Processos assíncronos serão executados por workers nativos usando PostgreSQL como fonte de verdade.

## MVP atual

- cálculo do custo real após desconto do fornecedor;
- kits;
- comissão;
- tarifa fixa;
- custo de frete do vendedor;
- custo operacional;
- valor recebido;
- lucro;
- margem;
- ROI;
- preço de equilíbrio;
- preço mínimo para atingir meta de margem + ROI;
- classificação automática;
- OAuth Mercado Livre conectado;
- interface visual-first;
- inteligência de mercado com anúncios comparáveis;
- faixa de preços P25/mediana/P75;
- fit score financeiro + mercado;
- cálculo do custo máximo de compra para competir;
- snapshots históricos de mercado.

A interface foi preparada para substituir os campos manuais pelos dados reais da API do Mercado Livre.

## Stack

- Next.js 16
- React 19
- TypeScript
- PostgreSQL 17
- Prisma 7
- workers nativos da aplicação
- Docker / Docker Compose
- Coolify

## Desenvolvimento

```bash
npm install
cp .env.example .env
docker compose up -d postgres
npm run db:deploy
npm run dev
```

## Coolify

O repositório segue o mesmo padrão dos demais apps:

1. recurso do tipo **Docker Compose**;
2. branch de desenvolvimento: `feature/ml-product-intelligence-mvp-v1`;
3. deploy automático ao receber push nessa branch;
4. domínio apontado para o serviço `app`, porta 3000;
5. PostgreSQL persistido em `postgres-data`;
6. migrations executadas automaticamente no start do container;
7. healthcheck em `/api/health`.

Variáveis automáticas do Coolify utilizadas:

- `SERVICE_LOWERCASEUSER_POSTGRES`
- `SERVICE_PASSWORD_64_POSTGRES`
- `SERVICE_REALBASE64_64_ENCRYPTION`
- `SERVICE_URL_APP_3000`

Variáveis externas:

- `MERCADO_LIVRE_CLIENT_ID`
- `MERCADO_LIVRE_CLIENT_SECRET`
- `MERCADO_LIVRE_REDIRECT_URI`

## Regras iniciais

- margem boa: >= 20%;
- margem mínima: 15%;
- ROI alvo: >= 30%;
- ROI abaixo de 20%: produto reprovado;
- fornecedor e desconto são configuráveis; nenhum fornecedor é fixo no produto.

Esses limites serão configuráveis.

## Roadmap

- [x] Infraestrutura deployável no Coolify
- [x] Motor financeiro inicial
- [x] Analisador manual
- [x] Base visual profissional
- [x] OAuth Mercado Livre
- [x] Tarifas e frete via API
- [x] Comparação Clássico x Premium
- [x] Simulação inicial de kits
- [x] Rotas separadas para análise, oportunidades, produtos, vendas e integrações
- [x] Busca por nome + EAN/GTIN + scanner de câmera quando suportado
- [x] Importação de pedidos
- [x] Custo real de envio por shipment
- [x] Lucro e margem realizados quando os custos estão completos
- [x] Product Health inicial com giro, cobertura e reposição
- [x] Inteligência de mercado e fit score
- [x] Tendências semanais + evidência de mais vendidos
- [ ] Webhook orders_v2 processado automaticamente
- [ ] histórico previsto × realizado
- [ ] lead time de fornecedor e estoque de segurança configurável


## Próximo foco

Validar em produção os cinco fluxos reais: busca/scan, análise, oportunidades, lucro realizado e Product Health. Depois disso, fechar processamento automático de `orders_v2`, previsto × realizado e reposição com lead time.

A camada de IA do MVP terá custo zero: apenas provedor gratuito ou modelo self-hosted, sempre opcional e desacoplado do motor financeiro.


## Documentação de desenvolvimento

Antes de implementar qualquer feature, consulte:

- `docs/PRODUCT_STRATEGY.md` — posicionamento, pilares e regra de priorização;
- `docs/FEATURES.md` — catálogo e ordem oficial das features inteligentes;
- `docs/DEVELOPMENT_CHECKLIST.md` — checklist obrigatório de implementação, teste e deploy;
- `docs/QUALITY_GATES.md` — bloqueios de qualidade que impedem tratar uma feature como pronta;
- `docs/ARCHITECTURE.md` — arquitetura e responsabilidades;
- `docs/DESIGN_SYSTEM.md` — regras visuais;
- `docs/AI_STRATEGY.md` — uso de IA sem comprometer os dados financeiros;
- `docs/MVP_CHECKLIST.md` — validação específica do MVP.

Regra: uma feature escrita no código não é automaticamente concluída. O status só avança após CI verde, deploy saudável e validação real quando aplicável.

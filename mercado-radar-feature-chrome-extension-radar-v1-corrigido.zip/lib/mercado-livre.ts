import { createHash } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { decryptSecret, encryptSecret } from "@/lib/security";

const API = "https://api.mercadolibre.com";

export type MlListingType = "CLASSIC" | "PREMIUM";

export function listingTypeId(type: MlListingType) {
  return type === "PREMIUM" ? "gold_pro" : "gold_special";
}

function credentials() {
  const clientId = process.env.MERCADO_LIVRE_CLIENT_ID;
  const clientSecret = process.env.MERCADO_LIVRE_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error("Credenciais do Mercado Livre não configuradas.");
  }

  return { clientId, clientSecret };
}

export type MlApiErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "RATE_LIMITED"
  | "UPSTREAM"
  | "TIMEOUT"
  | "HTTP";

/**
 * Erro tipado da API do Mercado Livre. Continua sendo um Error comum
 * (mesma mensagem amigável de antes), mas agora carrega status e rota para
 * que telas e diagnósticos distingam token, permissão, limite e indisponibilidade.
 */
export class MlApiError extends Error {
  readonly status: number;
  readonly path: string;
  readonly code: MlApiErrorCode;

  constructor(message: string, status: number, path: string, code: MlApiErrorCode) {
    super(message);
    this.name = "MlApiError";
    this.status = status;
    this.path = path;
    this.code = code;
  }
}

/* ---------- limitador de concorrência (processo único) ---------- */
const MAX_CONCURRENCY = Math.max(1, Number(process.env.ML_MAX_CONCURRENCY) || 6);
let activeRequests = 0;
const waiters: Array<() => void> = [];

async function acquireSlot() {
  if (activeRequests < MAX_CONCURRENCY) {
    activeRequests += 1;
    return;
  }
  // O slot é transferido diretamente para quem espera (activeRequests não muda).
  await new Promise<void>((resolve) => waiters.push(resolve));
}

function releaseSlot() {
  const next = waiters.shift();
  if (next) next();
  else activeRequests -= 1;
}

/* ---------- cache curto para GETs idempotentes ---------- */
const CACHE_RULES: Array<{ test: RegExp; ttlMs: number }> = [
  { test: /\/trends\//, ttlMs: 10 * 60_000 },
  { test: /\/highlights\//, ttlMs: 10 * 60_000 },
  { test: /\/products\/search\?/, ttlMs: 5 * 60_000 },
  { test: /\/products\/[A-Z0-9]+(\?|$)/, ttlMs: 5 * 60_000 },
  { test: /\/visits\/items\?/, ttlMs: 5 * 60_000 },
  { test: /\/items\/bulk\?/, ttlMs: 60_000 },
];
const CACHE_MAX_ENTRIES = 500;
const responseCache = new Map<string, { expiresAt: number; body: unknown }>();

function cacheTtl(url: string, method: string) {
  if (method !== "GET") return 0;
  return CACHE_RULES.find((rule) => rule.test.test(url))?.ttlMs ?? 0;
}

function cacheKey(url: string, init?: RequestInit) {
  const headers = new Headers(init?.headers);
  const auth = headers.get("authorization") ?? "";
  const who = auth
    ? createHash("sha1").update(auth).digest("hex").slice(0, 12)
    : "anon";
  return `${who}|${url}`;
}

function pathOf(url: string) {
  try {
    return new URL(url).pathname;
  } catch {
    return url;
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function retryDelayMs(attempt: number, retryAfter: string | null) {
  const seconds = retryAfter ? Number(retryAfter) : NaN;
  if (Number.isFinite(seconds) && seconds >= 0) {
    return Math.min(10_000, seconds * 1000);
  }
  return Math.min(8000, 500 * 2 ** attempt) + Math.floor(Math.random() * 250);
}

function isTimeout(error: unknown) {
  return (
    error instanceof Error &&
    (error.name === "TimeoutError" || error.name === "AbortError")
  );
}

function httpError(status: number, path: string, apiMessage: string): MlApiError {
  if (status === 401) {
    return new MlApiError(
      "A autorização do Mercado Livre expirou ou foi revogada. Reconecte a conta em Integrações.",
      status,
      path,
      "UNAUTHORIZED",
    );
  }
  if (status === 403) {
    return new MlApiError(
      "O Mercado Livre negou acesso a este recurso. A conta está conectada, mas o aplicativo precisa da permissão correspondente. Revise a integração do Mercado Livre.",
      status,
      path,
      "FORBIDDEN",
    );
  }
  if (status === 429) {
    return new MlApiError(
      "O Mercado Livre limitou temporariamente as consultas. O Radar tentará novamente quando o limite liberar.",
      status,
      path,
      "RATE_LIMITED",
    );
  }
  if (status >= 500) {
    return new MlApiError(
      "O Mercado Livre está temporariamente indisponível para esta consulta. Tente novamente em alguns instantes.",
      status,
      path,
      "UPSTREAM",
    );
  }
  return new MlApiError(
    apiMessage === "forbidden"
      ? "O Mercado Livre não autorizou esta consulta para o aplicativo conectado."
      : apiMessage,
    status,
    path,
    "HTTP",
  );
}

async function jsonFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const method = (init?.method ?? "GET").toUpperCase();
  const path = pathOf(url);
  const ttl = cacheTtl(url, method);
  const key = ttl ? cacheKey(url, init) : "";

  if (ttl) {
    const hit = responseCache.get(key);
    if (hit && hit.expiresAt > Date.now()) return hit.body as T;
    if (hit) responseCache.delete(key);
  }

  // Só repetimos GET: POST/PUT (ex.: /oauth/token) nunca devem ser reenviados.
  const maxAttempts = method === "GET" ? 3 : 1;
  let lastError: unknown;

  for (let attempt = 0; attempt < maxAttempts; attempt += 1) {
    await acquireSlot();
    let response: Response | null = null;
    let body: unknown = {};

    try {
      response = await fetch(url, {
        ...init,
        cache: "no-store",
        signal: AbortSignal.timeout(12000),
      });
      body = await response.json().catch(() => ({}));
    } catch (error) {
      lastError = isTimeout(error)
        ? new MlApiError(
            "O Mercado Livre demorou demais para responder. Tente novamente em alguns segundos.",
            0,
            path,
            "TIMEOUT",
          )
        : error;
      releaseSlot();
      // Timeout/rede: uma única repetição.
      if (attempt === 0 && maxAttempts > 1) {
        await sleep(retryDelayMs(attempt, null));
        continue;
      }
      throw lastError;
    }

    releaseSlot();

    if (response.ok) {
      if (ttl) {
        if (responseCache.size >= CACHE_MAX_ENTRIES) {
          const oldest = responseCache.keys().next().value;
          if (oldest) responseCache.delete(oldest);
        }
        responseCache.set(key, { expiresAt: Date.now() + ttl, body });
      }
      return body as T;
    }

    const apiMessage =
      typeof (body as { message?: unknown })?.message === "string"
        ? String((body as { message: string }).message)
        : `Mercado Livre respondeu HTTP ${response.status}`;
    lastError = httpError(response.status, path, apiMessage);

    const retryable =
      response.status === 429 ||
      response.status === 500 ||
      response.status === 502 ||
      response.status === 503 ||
      response.status === 504;

    if (retryable && attempt < maxAttempts - 1) {
      await sleep(retryDelayMs(attempt, response.headers.get("retry-after")));
      continue;
    }

    throw lastError;
  }

  throw lastError instanceof Error
    ? lastError
    : new Error("Falha ao consultar o Mercado Livre.");
}

export async function exchangeAuthorizationCode(input: {
  code: string;
  redirectUri: string;
  codeVerifier: string;
}) {
  const { clientId, clientSecret } = credentials();
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: clientId,
    client_secret: clientSecret,
    code: input.code,
    redirect_uri: input.redirectUri,
    code_verifier: input.codeVerifier,
  });

  return jsonFetch<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
    user_id: number;
    scope?: string;
  }>(`${API}/oauth/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
}

export async function fetchCurrentUser(accessToken: string) {
  return jsonFetch<{ id: number; nickname?: string }>(`${API}/users/me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });
}

async function refreshAccessToken(refreshToken: string) {
  const { clientId, clientSecret } = credentials();
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
  });

  return jsonFetch<{
    access_token: string;
    refresh_token?: string;
    expires_in: number;
    scope?: string;
  }>(`${API}/oauth/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
  });
}

export async function saveMlAccount(input: {
  userId: string;
  nickname?: string;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  scope?: string;
}) {
  return prisma.mercadoLivreAccount.upsert({
    where: { mercadoLivreUserId: input.userId },
    update: {
      nickname: input.nickname,
      accessTokenEncrypted: encryptSecret(input.accessToken),
      refreshTokenEncrypted: encryptSecret(input.refreshToken),
      tokenExpiresAt: new Date(Date.now() + input.expiresIn * 1000),
      scopes: input.scope,
    },
    create: {
      mercadoLivreUserId: input.userId,
      nickname: input.nickname,
      accessTokenEncrypted: encryptSecret(input.accessToken),
      refreshTokenEncrypted: encryptSecret(input.refreshToken),
      tokenExpiresAt: new Date(Date.now() + input.expiresIn * 1000),
      scopes: input.scope,
    },
  });
}

type MlAccountRecord = {
  id: string;
  mercadoLivreUserId: string;
  nickname: string | null;
  accessTokenEncrypted: string;
  refreshTokenEncrypted: string;
  tokenExpiresAt: Date;
  scopes: string | null;
  createdAt: Date;
  updatedAt: Date;
};

const REFRESH_MARGIN_MS = 5 * 60 * 1000;

function hasFreshToken(account: MlAccountRecord) {
  return account.tokenExpiresAt.getTime() > Date.now() + REFRESH_MARGIN_MS;
}

// O refresh token do Mercado Livre é de uso único: duas renovações simultâneas
// da mesma conta podem invalidar a conexão. Esta trava garante UMA renovação
// por conta neste processo; quem chegar durante a renovação reutiliza o resultado.
const refreshLocks = new Map<
  string,
  Promise<{ account: MlAccountRecord; accessToken: string }>
>();

async function refreshAccountSession(stale: MlAccountRecord) {
  // Outra requisição/processo pode ter renovado entre a leitura e a trava.
  const current =
    (await prisma.mercadoLivreAccount.findUnique({ where: { id: stale.id } })) ??
    stale;

  if (hasFreshToken(current)) {
    return {
      account: current,
      accessToken: decryptSecret(current.accessTokenEncrypted),
    };
  }

  let refreshed: Awaited<ReturnType<typeof refreshAccessToken>>;

  try {
    refreshed = await refreshAccessToken(
      decryptSecret(current.refreshTokenEncrypted),
    );
  } catch (error) {
    // Se outro processo (ex.: cron) rotacionou o token enquanto tentávamos,
    // o banco já tem um token válido: usamos ele em vez de derrubar a sessão.
    const latest = await prisma.mercadoLivreAccount.findUnique({
      where: { id: current.id },
    });

    if (
      latest &&
      latest.refreshTokenEncrypted !== current.refreshTokenEncrypted &&
      hasFreshToken(latest)
    ) {
      return {
        account: latest,
        accessToken: decryptSecret(latest.accessTokenEncrypted),
      };
    }

    throw error;
  }

  const updated = await prisma.mercadoLivreAccount.update({
    where: { id: current.id },
    data: {
      accessTokenEncrypted: encryptSecret(refreshed.access_token),
      refreshTokenEncrypted: refreshed.refresh_token
        ? encryptSecret(refreshed.refresh_token)
        : current.refreshTokenEncrypted,
      tokenExpiresAt: new Date(Date.now() + refreshed.expires_in * 1000),
      scopes: refreshed.scope ?? current.scopes,
    },
  });

  return { account: updated, accessToken: refreshed.access_token };
}

async function buildMlSession(account: MlAccountRecord) {
  if (hasFreshToken(account)) {
    return {
      account,
      accessToken: decryptSecret(account.accessTokenEncrypted),
    };
  }

  const running = refreshLocks.get(account.id);
  if (running) return running;

  const task = refreshAccountSession(account).finally(() => {
    refreshLocks.delete(account.id);
  });
  refreshLocks.set(account.id, task);
  return task;
}

export async function getMlSession() {
  // Painel web (single-tenant): se ADMIN_ML_ACCOUNT_ID estiver definido, usa
  // exatamente essa conta. Sem ele mantém o comportamento anterior (conta mais
  // recente), o que é arriscado quando há contas de extensão no mesmo banco.
  const pinned = process.env.ADMIN_ML_ACCOUNT_ID?.trim();

  const account = pinned
    ? await prisma.mercadoLivreAccount.findUnique({ where: { id: pinned } })
    : await prisma.mercadoLivreAccount.findFirst({
        orderBy: { updatedAt: "desc" },
      });

  if (!account) {
    throw new Error("Conta do Mercado Livre ainda não conectada.");
  }

  return buildMlSession(account);
}

export async function getMlSessionForAccount(accountId: string) {
  const account = await prisma.mercadoLivreAccount.findUnique({
    where: { id: accountId },
  });

  if (!account) {
    throw new Error("Conta do Mercado Livre vinculada à extensão não encontrada.");
  }

  return buildMlSession(account);
}

export async function getListingPriceQuote(input: {
  accessToken: string;
  price: number;
  categoryId: string;
  listingType: MlListingType;
  logisticType?: string;
  shippingMode?: string;
}) {
  const query = new URLSearchParams({
    price: String(input.price),
    currency_id: "BRL",
    category_id: input.categoryId,
    listing_type_id: listingTypeId(input.listingType),
    logistic_type: input.logisticType ?? "drop_off",
    shipping_mode: input.shippingMode ?? "me2",
  });

  const raw = await jsonFetch<any>(
    `${API}/sites/MLB/listing_prices?${query.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  const quote = Array.isArray(raw) ? raw[0] : raw;
  if (!quote) {
    throw new Error("Mercado Livre não retornou tarifa para essa combinação.");
  }

  const saleFeeAmount = Number(quote.sale_fee_amount ?? 0);
  const fixedFee = Number(quote.sale_fee_details?.fixed_fee ?? 0);
  const variableFee = Math.max(0, saleFeeAmount - fixedFee);
  const commissionPercent =
    input.price > 0 ? (variableFee / input.price) * 100 : 0;

  return {
    raw,
    saleFeeAmount,
    fixedFee,
    commissionPercent,
  };
}

export async function getShippingQuote(input: {
  accessToken: string;
  userId: string;
  price: number;
  listingType: MlListingType;
  weightGrams: number;
  heightCm: number;
  widthCm: number;
  lengthCm: number;
  logisticType?: string;
  shippingMode?: string;
}) {
  const dimensions =
    `${Math.round(input.heightCm)}x${Math.round(input.widthCm)}x${Math.round(input.lengthCm)},${Math.round(input.weightGrams)}`;

  const query = new URLSearchParams({
    dimensions,
    verbose: "true",
    item_price: String(input.price),
    listing_type_id: listingTypeId(input.listingType),
    mode: input.shippingMode ?? "me2",
    condition: "new",
    logistic_type: input.logisticType ?? "drop_off",
    free_shipping: "True",
  });

  const raw = await jsonFetch<any>(
    `${API}/users/${input.userId}/shipping_options/free?${query.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  const coverage = raw?.coverage?.all_country;
  if (!coverage) {
    throw new Error("Mercado Livre não retornou cotação de frete.");
  }

  return {
    raw,
    shippingCost: Number(coverage.list_cost ?? 0),
    billableWeight: Number(coverage.billable_weight ?? input.weightGrams),
    discountRate: Number(coverage.discount?.rate ?? 0),
    promotedAmount: Number(coverage.discount?.promoted_amount ?? 0),
  };
}


export async function predictCategory(input: {
  accessToken: string;
  title: string;
  limit?: number;
}) {
  const query = new URLSearchParams({
    q: input.title,
    limit: String(input.limit ?? 3),
  });

  let raw: Array<{
    domain_id?: string;
    domain_name?: string;
    category_id: string;
    category_name: string;
    attributes?: Array<{
      id: string;
      value_id?: string;
      value_name?: string;
    }>;
  }>;

  try {
    raw = await jsonFetch(
      `${API}/sites/MLB/domain_discovery/search?${query.toString()}`,
      { headers: { Authorization: `Bearer ${input.accessToken}` } },
    );
  } catch {
    raw = await jsonFetch(
      `${API}/sites/MLB/domain_discovery/search?${query.toString()}`,
    );
  }

  return raw.map((item) => ({
    domainId: item.domain_id ?? null,
    domainName: item.domain_name ?? null,
    categoryId: item.category_id,
    categoryName: item.category_name,
    attributes: item.attributes ?? [],
  }));
}


export type MarketplaceSearchItem = {
  id: string;
  title: string;
  price: number;
  currencyId: string;
  permalink: string | null;
  thumbnail: string | null;
  categoryId: string | null;
  sellerId: string | null;
  listingTypeId: string | null;
  freeShipping: boolean;
};

export async function searchMarketplace(input: {
  accessToken: string;
  query: string;
  categoryId?: string;
  limit?: number;
}) {
  const params = new URLSearchParams({
    q: input.query,
    limit: String(Math.min(Math.max(input.limit ?? 30, 1), 50)),
  });

  if (input.categoryId) {
    params.set("category", input.categoryId);
  }

  type MarketplaceSearchResponse = {
    results?: Array<{
      id?: string;
      title?: string;
      price?: number;
      currency_id?: string;
      permalink?: string;
      thumbnail?: string;
      category_id?: string;
      seller?: { id?: number | string };
      listing_type_id?: string;
      shipping?: {
        free_shipping?: boolean;
        logistic_type?: string;
        mode?: string;
      };
    }>;
  };

  let raw: MarketplaceSearchResponse;

  const searchUrl = `${API}/sites/MLB/search?${params.toString()}`;

  try {
    raw = await jsonFetch<MarketplaceSearchResponse>(searchUrl, {
      headers: { Authorization: `Bearer ${input.accessToken}` },
    });
  } catch (authenticatedError) {
    // Tentativa pública mantida por compatibilidade, mas o erro REAL (ex.: 403
    // de permissão) é preservado: antes ele era substituído pelo da segunda
    // chamada e o diagnóstico ficava enganoso.
    try {
      raw = await jsonFetch<MarketplaceSearchResponse>(searchUrl);
    } catch {
      throw authenticatedError;
    }
  }

  return (raw.results ?? [])
    .filter((item) => item.id && item.title)
    .map<MarketplaceSearchItem>((item) => ({
      id: String(item.id),
      title: String(item.title),
      price: Number(item.price ?? 0),
      currencyId: String(item.currency_id ?? "BRL"),
      permalink: item.permalink ?? null,
      thumbnail: item.thumbnail ?? null,
      categoryId: item.category_id ?? null,
      sellerId: item.seller?.id == null ? null : String(item.seller.id),
      listingTypeId: item.listing_type_id ?? null,
      freeShipping: Boolean(item.shipping?.free_shipping),
    }));
}

export async function getItemCurrentPrice(input: {
  accessToken: string;
  itemId: string;
}) {
  const raw = await jsonFetch<{
    prices?: Array<{
      type?: string;
      amount?: number;
      conditions?: {
        context_restrictions?: string[];
        min_purchase_unit?: number;
      };
    }>;
  }>(`${API}/items/${input.itemId}/prices`, {
    headers: { Authorization: `Bearer ${input.accessToken}` },
  });

  const prices = (raw.prices ?? []).filter(
    (price) => Number(price.amount) > 0,
  );

  const consumerPrices = prices.filter((price) => {
    const restrictions = price.conditions?.context_restrictions ?? [];
    return (
      !restrictions.includes("user_type_business") &&
      (price.conditions?.min_purchase_unit ?? 1) <= 1
    );
  });

  const candidates = consumerPrices.length > 0 ? consumerPrices : prices;
  const promotion = candidates.find((price) => price.type === "promotion");
  const standard = candidates.find((price) => price.type === "standard");
  const selected = promotion ?? standard ?? candidates[0];

  return selected ? Number(selected.amount) : null;
}


export async function getSellerItemIds(input: {
  accessToken: string;
  userId: string;
  status?: string;
  limit?: number;
  offset?: number;
}) {
  const params = new URLSearchParams({
    limit: String(Math.min(Math.max(input.limit ?? 50, 1), 50)),
    offset: String(Math.max(input.offset ?? 0, 0)),
  });

  if (input.status) params.set("status", input.status);

  return jsonFetch<{
    seller_id?: string | number;
    paging?: { total?: number; offset?: number; limit?: number };
    results?: string[];
  }>(
    `${API}/users/${input.userId}/items/search?${params.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );
}

export type SellerItemDetail = {
  id: string;
  title: string;
  categoryId: string | null;
  status: string;
  listingTypeId: string | null;
  currentPrice: number;
  sellerId: string | null;
  catalogProductId: string | null;
  userProductId: string | null;
  availableQuantity: number;
  soldQuantity: number;
  dateCreated: string | null;
  permalink: string | null;
  thumbnail: string | null;
  freeShipping: boolean;
  logisticType: string | null;
  shippingMode: string | null;
  sellerSku: string | null;
  raw: unknown;
};

export async function getItemsBulk(input: {
  accessToken: string;
  itemIds: string[];
}) {
  if (input.itemIds.length === 0) return [] as SellerItemDetail[];

  const ids = input.itemIds.slice(0, 50).join(",");
  const params = new URLSearchParams({
    ids,
    attributes: [
      "body.id",
      "body.title",
      "body.category_id",
      "body.status",
      "body.listing_type_id",
      "body.price",
      "body.seller_id",
      "body.catalog_product_id",
      "body.user_product_id",
      "body.available_quantity",
      "body.sold_quantity",
      "body.date_created",
      "body.permalink",
      "body.thumbnail",
      "body.shipping",
      "body.seller_custom_field",
      "body.attributes",
    ].join(","),
  });

  const raw = await jsonFetch<Array<{
    id?: string;
    status_code?: number;
    body?: {
      id?: string;
      title?: string;
      category_id?: string;
      status?: string;
      listing_type_id?: string;
      price?: number;
      seller_id?: string | number;
      catalog_product_id?: string;
      user_product_id?: string;
      available_quantity?: number;
      sold_quantity?: number;
      date_created?: string;
      permalink?: string;
      thumbnail?: string;
      seller_custom_field?: string;
      shipping?: {
        free_shipping?: boolean;
        logistic_type?: string;
        mode?: string;
      };
      attributes?: Array<{
        id?: string;
        value_name?: string;
      }>;
    };
  }>>(
    `${API}/items/bulk?${params.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  return raw
    .filter((entry) => entry.body?.id)
    .map<SellerItemDetail>((entry) => {
      const body = entry.body!;
      const sellerSku =
        body.seller_custom_field ??
        body.attributes?.find((attribute) => attribute.id === "SELLER_SKU")
          ?.value_name ??
        null;

      return {
        id: String(body.id),
        title: String(body.title ?? body.id),
        categoryId: body.category_id ?? null,
        status: String(body.status ?? "unknown"),
        listingTypeId: body.listing_type_id ?? null,
        currentPrice: Number(body.price ?? 0),
        sellerId: body.seller_id == null ? null : String(body.seller_id),
        catalogProductId: body.catalog_product_id ?? null,
        userProductId: body.user_product_id ?? null,
        availableQuantity: Number(body.available_quantity ?? 0),
        soldQuantity: Number(body.sold_quantity ?? 0),
        dateCreated: body.date_created ?? null,
        permalink: body.permalink ?? null,
        thumbnail: body.thumbnail ?? null,
        freeShipping: Boolean(body.shipping?.free_shipping),
        logisticType: body.shipping?.logistic_type ?? null,
        shippingMode: body.shipping?.mode ?? null,
        sellerSku,
        raw: entry,
      };
    });
}

export async function getItemsCurrentPrices(input: {
  accessToken: string;
  itemIds: string[];
}) {
  const entries = await Promise.all(
    input.itemIds.slice(0, 50).map(async (itemId) => {
      try {
        const price = await getItemCurrentPrice({
          accessToken: input.accessToken,
          itemId,
        });
        return [itemId, price] as const;
      } catch {
        return [itemId, null] as const;
      }
    }),
  );

  return Object.fromEntries(entries) as Record<string, number | null>;
}

export async function getItemsVisitTotals(input: {
  accessToken: string;
  itemIds: string[];
}) {
  if (input.itemIds.length === 0) return {} as Record<string, number>;

  const params = new URLSearchParams({
    ids: input.itemIds.slice(0, 50).join(","),
  });

  const raw = await jsonFetch<Record<string, number>>(
    `${API}/visits/items?${params.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  return raw;
}

export type SellerOrderSearchResult = {
  paging?: {
    total?: number;
    offset?: number;
    limit?: number;
  };
  results?: Array<Record<string, any>>;
};

export async function getSellerOrders(input: {
  accessToken: string;
  userId: string;
  days?: number;
  limit?: number;
  offset?: number;
}) {
  const days = Math.min(Math.max(input.days ?? 30, 1), 365);
  const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const params = new URLSearchParams({
    seller: input.userId,
    limit: String(Math.min(Math.max(input.limit ?? 50, 1), 50)),
    offset: String(Math.max(input.offset ?? 0, 0)),
    "order.date_created.from": from.toISOString(),
  });

  return jsonFetch<SellerOrderSearchResult>(
    `${API}/orders/search?${params.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );
}


export type CatalogProductSearchResult = {
  id: string;
  name: string;
  domainId: string | null;
  status: string | null;
  attributes: Array<{
    id: string;
    name?: string;
    valueName?: string;
  }>;
  pictures: Array<{ id?: string; url?: string }>;
  raw: unknown;
};

export async function searchCatalogProducts(input: {
  accessToken: string;
  query?: string;
  productIdentifier?: string;
  limit?: number;
}) {
  const params = new URLSearchParams({
    site_id: "MLB",
    status: "active",
    limit: String(Math.min(Math.max(input.limit ?? 10, 1), 20)),
  });

  if (input.productIdentifier) {
    params.set("product_identifier", input.productIdentifier);
  } else if (input.query) {
    params.set("q", input.query);
  } else {
    throw new Error("Informe um nome ou código de barras.");
  }

  const raw = await jsonFetch<{
    results?: Array<{
      id?: string;
      name?: string;
      domain_id?: string;
      status?: string;
      attributes?: Array<{
        id?: string;
        name?: string;
        value_name?: string;
      }>;
      pictures?: Array<{ id?: string; url?: string }>;
    }>;
  }>(`${API}/products/search?${params.toString()}`, {
    headers: { Authorization: `Bearer ${input.accessToken}` },
  });

  return (raw.results ?? [])
    .filter((item) => item.id && item.name)
    .map<CatalogProductSearchResult>((item) => ({
      id: String(item.id),
      name: String(item.name),
      domainId: item.domain_id ?? null,
      status: item.status ?? null,
      attributes: (item.attributes ?? [])
        .filter((attribute) => attribute.id)
        .map((attribute) => ({
          id: String(attribute.id),
          name: attribute.name,
          valueName: attribute.value_name,
        })),
      pictures: item.pictures ?? [],
      raw: item,
    }));
}

export async function getItemFullDetails(input: {
  accessToken: string;
  itemId: string;
}) {
  return jsonFetch<{
    id?: string;
    title?: string;
    category_id?: string;
    attributes?: Array<{
      id?: string;
      name?: string;
      value_name?: string;
      value_struct?: {
        number?: number;
        unit?: string;
      } | null;
      values?: Array<{
        name?: string;
        struct?: {
          number?: number;
          unit?: string;
        } | null;
      }>;
    }>;
    shipping?: {
      dimensions?: string | null;
      free_shipping?: boolean;
    };
  }>(
    `${API}/items/${input.itemId}?include_attributes=all`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );
}

export async function getTrends(input: {
  accessToken: string;
  categoryId?: string;
}) {
  const suffix = input.categoryId ? `/${input.categoryId}` : "";
  return jsonFetch<Array<{ keyword: string; url?: string }>>(
    `${API}/trends/MLB${suffix}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );
}

export async function getCategoryHighlights(input: {
  accessToken: string;
  categoryId: string;
}) {
  return jsonFetch<{
    query_data?: {
      highlight_type?: string;
      criteria?: string;
      id?: string;
    };
    content?: Array<{
      id: string;
      position: number;
      type: "ITEM" | "PRODUCT" | "USER_PRODUCT" | string;
    }>;
  }>(
    `${API}/highlights/MLB/category/${input.categoryId}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );
}


export async function getShipmentCosts(input: {
  accessToken: string;
  shipmentId: string;
}) {
  const raw = await jsonFetch<{
    gross_amount?: number;
    receiver?: {
      cost?: number;
      promoted_amount?: number;
    };
    senders?: Array<{
      id?: number | string;
      cost?: number;
      promoted_amount?: number;
    }>;
  }>(
    `${API}/shipments/${input.shipmentId}/costs`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
        "x-format-new": "true",
      },
    },
  );

  const sellerCost = (raw.senders ?? []).reduce(
    (sum, sender) => sum + Number(sender.cost ?? 0),
    0,
  );

  return {
    raw,
    sellerCost,
    buyerCost: Number(raw.receiver?.cost ?? 0),
    grossAmount: Number(raw.gross_amount ?? 0),
  };
}


export async function getOrderShipment(input: {
  accessToken: string;
  orderId: string;
}) {
  type ShipmentRecord = {
    id?: number | string;
    order_cost?: number;
    base_cost?: number;
    status?: string;
    substatus?: string | null;
  };

  const raw = await jsonFetch<ShipmentRecord | ShipmentRecord[]>(
    `${API}/orders/${input.orderId}/shipments`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
        "x-format-new": "true",
      },
    },
  );

  const shipment = Array.isArray(raw) ? raw[0] ?? null : raw;

  return {
    raw,
    shipmentId:
      shipment?.id == null ? null : String(shipment.id),
    orderCost:
      shipment?.order_cost == null
        ? null
        : Number(shipment.order_cost),
  };
}


export async function getCatalogProductDetails(input: {
  accessToken: string;
  productId: string;
}) {
  return jsonFetch<{
    id?: string;
    name?: string;
    family_name?: string;
    domain_id?: string;
    status?: string;
    sold_quantity?: number;
    permalink?: string;
    attributes?: Array<{
      id?: string;
      name?: string;
      value_name?: string;
      value_struct?: {
        number?: number;
        unit?: string;
      } | null;
      values?: Array<{
        name?: string;
        struct?: {
          number?: number;
          unit?: string;
        } | null;
      }>;
    }>;
    buy_box_winner?: {
      item_id?: string;
      category_id?: string;
      seller_id?: number | string;
      price?: number;
      currency_id?: string;
      available_quantity?: number;
      sold_quantity?: number;
      shipping?: {
        free_shipping?: boolean;
        logistic_type?: string;
      };
    } | null;
  }>(
    `${API}/products/${input.productId}`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
      },
    },
  );
}


export async function getCatalogCompetition(input: {
  accessToken: string;
  itemId: string;
}) {
  return jsonFetch<{
    item_id?: string;
    current_price?: number;
    currency_id?: string;
    price_to_win?: number | null;
    status?:
      | "winning"
      | "competing"
      | "sharing_first_place"
      | "listed"
      | string;
    consistent?: boolean;
    visit_share?: string | null;
    competitors_sharing_first_place?: number | null;
    reason?: string[];
    catalog_product_id?: string | null;
    boosts?: Array<{
      id?: string;
      status?: string;
      description?: string;
    }>;
    winner?: {
      item_id?: string;
      price?: number;
      currency_id?: string;
      boosts?: Array<{
        id?: string;
        status?: string;
        description?: string;
      }>;
    } | null;
  }>(
    `${API}/items/${input.itemId}/price_to_win?siteId=MLB&version=v2`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
      },
    },
  );
}


export async function getExistingItemShippingQuote(input: {
  accessToken: string;
  userId: string;
  itemId: string;
  price: number;
  listingType: MlListingType;
  freeShipping: boolean;
}) {
  const query = new URLSearchParams({
    item_id: input.itemId,
    verbose: "true",
    item_price: String(input.price),
    listing_type_id: listingTypeId(input.listingType),
    free_shipping: input.freeShipping ? "True" : "False",
  });

  const raw = await jsonFetch<any>(
    `${API}/users/${input.userId}/shipping_options/free?${query.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  const coverage = raw?.coverage?.all_country;
  if (!coverage) {
    throw new Error("Mercado Livre não retornou o custo de envio do anúncio.");
  }

  return {
    raw,
    shippingCost: Number(coverage.list_cost ?? 0),
    billableWeight: Number(coverage.billable_weight ?? 0),
    discountRate: Number(coverage.discount?.rate ?? 0),
    promotedAmount: Number(coverage.discount?.promoted_amount ?? 0),
  };
}


export async function getUserProductDetails(input: {
  accessToken: string;
  userProductId: string;
}) {
  return jsonFetch<{
    id?: string;
    user_id?: number | string;
    family_id?: number | string;
    family_name?: string;
    domain_id?: string;
    site_id?: string;
    attributes?: Array<{
      id?: string;
      name?: string;
      values?: Array<{ id?: string | null; name?: string | null }>;
    }>;
  }>(
    `${API}/user-products/${input.userProductId}`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
        "X-API-Version": "2",
      },
    },
  );
}

export async function getItemsByUserProduct(input: {
  accessToken: string;
  userId: string;
  userProductId: string;
}) {
  const params = new URLSearchParams({
    user_product_id: input.userProductId,
    limit: "50",
  });

  const raw = await jsonFetch<{
    results?: string[];
  }>(
    `${API}/users/${input.userId}/items/search?${params.toString()}`,
    { headers: { Authorization: `Bearer ${input.accessToken}` } },
  );

  return raw.results ?? [];
}


export type ProductAdsAdvertiser = {
  advertiserId: string;
  siteId: string;
  advertiserName: string | null;
  accountName: string | null;
};

export async function getProductAdsAdvertisers(input: {
  accessToken: string;
}) {
  const raw = await jsonFetch<{
    advertisers?: Array<{
      advertiser_id?: number | string;
      site_id?: string;
      advertiser_name?: string;
      account_name?: string;
    }>;
  }>(`${API}/advertising/advertisers?product_id=PADS`, {
    headers: {
      Authorization: `Bearer ${input.accessToken}`,
      "Content-Type": "application/json",
      "Api-Version": "1",
    },
  });

  return (raw.advertisers ?? [])
    .filter((item) => item.advertiser_id != null && item.site_id)
    .map<ProductAdsAdvertiser>((item) => ({
      advertiserId: String(item.advertiser_id),
      siteId: String(item.site_id),
      advertiserName: item.advertiser_name ?? null,
      accountName: item.account_name ?? null,
    }));
}

const PRODUCT_ADS_CAMPAIGN_METRICS = [
  "clicks",
  "prints",
  "ctr",
  "cost",
  "cpc",
  "acos",
  "organic_units_quantity",
  "organic_units_amount",
  "organic_items_quantity",
  "direct_items_quantity",
  "indirect_items_quantity",
  "advertising_items_quantity",
  "cvr",
  "roas",
  "sov",
  "direct_units_quantity",
  "indirect_units_quantity",
  "units_quantity",
  "direct_amount",
  "indirect_amount",
  "total_amount",
].join(",");

const PRODUCT_ADS_AD_GROUP_METRICS = [
  "CLICKS",
  "PRINTS",
  "COST",
  "CPC",
  "CTR",
  "DIRECT_AMOUNT",
  "INDIRECT_AMOUNT",
  "TOTAL_AMOUNT",
  "DIRECT_UNITS_QUANTITY",
  "INDIRECT_UNITS_QUANTITY",
  "UNITS_QUANTITY",
  "DIRECT_ITEMS_QUANTITY",
  "INDIRECT_ITEMS_QUANTITY",
  "ADVERTISING_ITEMS_QUANTITY",
  "ORGANIC_UNITS_QUANTITY",
  "ORGANIC_UNITS_AMOUNT",
  "ORGANIC_ITEMS_QUANTITY",
  "ACOS",
  "TACOS",
  "SOV",
  "CVR",
  "ROAS",
].join(",");

export async function getProductAdsCampaigns(input: {
  accessToken: string;
  siteId: string;
  advertiserId: string;
  dateFrom: string;
  dateTo: string;
  limit?: number;
  offset?: number;
}) {
  const params = new URLSearchParams({
    limit: String(Math.min(Math.max(input.limit ?? 50, 1), 50)),
    offset: String(Math.max(input.offset ?? 0, 0)),
    date_from: input.dateFrom,
    date_to: input.dateTo,
    metrics: PRODUCT_ADS_CAMPAIGN_METRICS,
    metrics_summary: "true",
  });

  return jsonFetch<{
    paging?: { offset?: number; total?: number; limit?: number };
    results?: Array<Record<string, any>>;
    metrics_summary?: Record<string, number | null>;
  }>(
    `${API}/advertising/${input.siteId}/advertisers/${input.advertiserId}/product_ads/campaigns/search?${params.toString()}`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
        "api-version": "2",
      },
    },
  );
}

export async function getProductAdsAdGroups(input: {
  accessToken: string;
  siteId: string;
  advertiserId: string;
  dateFrom: string;
  dateTo: string;
  limit?: number;
  offset?: number;
}) {
  const params = new URLSearchParams({
    limit: String(Math.min(Math.max(input.limit ?? 50, 1), 800)),
    offset: String(Math.max(input.offset ?? 0, 0)),
    date_from: input.dateFrom,
    date_to: input.dateTo,
    metrics: PRODUCT_ADS_AD_GROUP_METRICS,
    metrics_summary: "true",
    sort: "desc",
    sort_by: "cost",
  });

  return jsonFetch<{
    paging?: { offset?: number; total?: number; limit?: number };
    results?: Array<Record<string, any>>;
    metrics_summary?: Record<string, number | null>;
  }>(
    `${API}/advertising/${input.siteId}/advertisers/${input.advertiserId}/product_ads/ad_groups/search?${params.toString()}`,
    {
      headers: {
        Authorization: `Bearer ${input.accessToken}`,
        "api-version": "2",
      },
    },
  );
}
